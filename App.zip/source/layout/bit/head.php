
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>BremitBMS<?php if(fia::route() != 'index'){echo ' - '.oString::to(fia::route(), 'oTITLE');} else {echo ' App';}?></title>
<link href="/asset/main.css" rel="stylesheet">
<link href="//cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css" rel="stylesheet" crossorigin="anonymous">
<link href="/asset/vae.css" rel="stylesheet">
<script src="//cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/js/all.min.js" crossorigin="anonymous"></script>
<link id=favicon rel=icon type="image/x-icon" href="/favicon.ico">
