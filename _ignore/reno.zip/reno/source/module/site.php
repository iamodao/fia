<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
	<title>Site Index</title>
	<link rel="shortcut icon" href="./favicon.ico">
	<link href="" type="text/css" rel="stylesheet" media="all">
</head>
<body>
	<h1>SITE INDEX</h1>
	<p>This is the default controller for <em>website</em></p>
	<p>It is not meant to be your index view, rather a default handler for your website.<br> If you understand the framework, you would like to clear this content and have some dynamic logic handling your pages/views</p>
	<script src="" type="text/javascript"></script>
</body>
</html>