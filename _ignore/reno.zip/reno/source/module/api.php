<?php
// api primary controller
class oAPI {
}
?>