<?php
// app primary controller
class oAPP {
}
?>