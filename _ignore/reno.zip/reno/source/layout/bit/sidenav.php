<nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
	<div class="sb-sidenav-menu">
		<div class="nav">
			<a class="nav-link" href="/dashboard">
				<div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div> Dashboard
			</a>
			
			<!-- <div class="sb-sidenav-menu-heading">Manage</div>
			<a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#hotel-menu" aria-expanded="false" aria-controls="hotel-menu">
				<div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div> Hotel
				
				<div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
			</a>
			<div class="collapse" id="hotel-menu" aria-labelledby="headingOne" data-parent="#sidenavAccordion">
				<nav class="sb-sidenav-menu-nested nav">
					<a class="nav-link" href="/rooms">Rooms</a>
					<a class="nav-link" href="/room-category">Room Category</a>
				</nav>
			</div> -->
			

			<!-- <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseHotel" aria-expanded="false" aria-controls="collapseHotel">
				<div class="sb-nav-link-icon"><i class="fas fa-book-open"></i></div>
				Pages
				<div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
			</a>
			<div class="collapse" id="collapsePages" aria-labelledby="headingTwo" data-parent="#sidenavAccordion">
				<nav class="sb-sidenav-menu-nested nav accordion" id="sidenavAccordionPages"> <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#pagesCollapseAuth" aria-expanded="false" aria-controls="pagesCollapseAuth">Authentication
					<div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
				</a>
				<div class="collapse" id="pagesCollapseAuth" aria-labelledby="headingOne" data-parent="#sidenavAccordionPages">
					<nav class="sb-sidenav-menu-nested nav"><a class="nav-link" href="login.html">Login</a><a class="nav-link" href="register.html">Register</a><a class="nav-link" href="password.html">Forgot Password</a></nav>
				</div>
				<a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#pagesCollapseError" aria-expanded="false" aria-controls="pagesCollapseError">Error
					<div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
				</a>
				<div class="collapse" id="pagesCollapseError" aria-labelledby="headingOne" data-parent="#sidenavAccordionPages">
					<nav class="sb-sidenav-menu-nested nav"><a class="nav-link" href="401.html">401 Page</a><a class="nav-link" href="404.html">404 Page</a><a class="nav-link" href="500.html">500 Page</a></nav>
				</div>
			</nav>
		</div> -->
		<div class="sb-sidenav-menu-heading">Booking</div>
		<a class="nav-link" href="/update-profile">
			<div class="sb-nav-link-icon"><i class="fas fa-hotel"></i></div> Hotel
		</a>
		<a class="nav-link" href="//booking?type=spa">
			<div class="sb-nav-link-icon"><i class="fas fa-spa"></i></div> Salon
		</a>
		<a class="nav-link" href="/booking?type=cleaning">
			<div class="sb-nav-link-icon"><i class="fas fa-quidditch"></i></div> Cleaning
		</a>

		<div class="sb-sidenav-menu-heading">Settings</div>
		<a class="nav-link" href="/update-profile">
			<div class="sb-nav-link-icon"><i class="fas fa-user-edit"></i></div> Update Profile
		</a>
		<a class="nav-link" href="/change-password">
			<div class="sb-nav-link-icon"><i class="fas fa-key"></i></div> Change Password
		</a>
		<a class="nav-link" href="/logout">
			<div class="sb-nav-link-icon"><i class="fas fa-sign-out-alt"></i></div> Logout
		</a>
	</div>
</div>
<?php fia::bit('nav.user');?>
</nav>