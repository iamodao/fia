
<script src="/asset/js/jquery-3.4.1.min.js" crossorigin="anonymous"></script>
<script src="/asset/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
<script src="/asset/js/scripts.js"></script>
<script src="/asset/js/Chart.min.js" crossorigin="anonymous"></script>
<script src="/asset/demo/chart-area-demo.js"></script>
<script src="/asset/demo/chart-bar-demo.js"></script>
<script src="/asset/js/jquery.dataTables.min.js" crossorigin="anonymous"></script>
<script src="/asset/js/dataTables.bootstrap4.min.js" crossorigin="anonymous"></script>
<script src="/asset/demo/datatables-demo.js"></script>
