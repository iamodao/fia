<div class="sb-sidenav-footer">
	<div class="small">Logged in as:</div>
	<strong>ODAO</strong>
</div>