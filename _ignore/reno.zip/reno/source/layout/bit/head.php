	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="author" content="Anthony Osawere - anthony@osawere.com">
	<title>Bremit Booking</title>
	<link href="/asset/css/styles.css" rel="stylesheet">
	<link href="/asset/css/dataTables.bootstrap4.min.css" rel="stylesheet" crossorigin="anonymous">
	<script src="/asset/js/fontawesome.min.js" crossorigin="anonymous"></script>