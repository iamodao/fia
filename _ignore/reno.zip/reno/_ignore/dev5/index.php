<!DOCTYPE html>
<html lang="en">
<head>
	<?php $fia->bit('head');?>
</head>
<body class="sb-nav-fixed">
	<?php $fia->bit('topnav');?>

	<div id="layoutSidenav">
		<div id="layoutSidenav_nav">
			<?php $fia->bit('sidenav');?>
		</div>
		<div id="layoutSidenav_content">
			<?php $fia->bit('view.main');?>
			<?php $fia->bit('footer');?>
		</div>
	</div>
	<?php $fia->bit('js');?>
</body>
</html>